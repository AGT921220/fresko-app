(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["referred-referred-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/referred/referred.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/referred/referred.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<ion-content>\r\n  <ion-item class=\"header ion-text-center\" style=\"padding-top:8%\">\r\n    <div class=\"first\">\r\n      <ion-img src=\"assets/header_mercasa.png\"\r\n        style=\"width: 55%;padding-left: 0px !important;margin-left: 0px !important;padding-top: 0px !important;margin-top: 0px !important;\"\r\n        class=\"img_header ion-margin-top ion-padding-top\">\r\n      </ion-img>\r\n    </div>\r\n    <div class=\"second\">\r\n      <ion-img src=\"assets/cart_logo.png\" class=\"img_header ion-margin-top ion-padding-top\"\r\n        style=\"padding-top: 0px;margin-top: 0px;width: 70%;float: right;\" (click)=\"shoppingList()\">\r\n      </ion-img>\r\n    </div>\r\n\r\n  </ion-item>\r\n\r\n\r\n  <div style=\"text-align:center\">\r\n    <h3>Referidos</h3>\r\n    <p style=\"color:#00b050; font-size: 1.5em;\">{{referreds}}</p>\r\n  </div>\r\n\r\n\r\n  <div style=\"text-align:center\">\r\n    <h3>Saldo</h3>\r\n    <p style=\"color: #ffffff;\r\n    background-color: #00b050;\r\n    width: 60%;\r\n    margin: auto;\r\n    padding: 0.5em;\r\n    border-radius: 10px;\r\n    font-weight: bold;\r\n    font-size: 1.5em;\">${{balance.toFixed(2)}}</p>\r\n  </div>\r\n\r\n\r\n\r\n  <table id=\"commissions\" *ngIf=\"referredCommissions!=0\">\r\n    <thead>\r\n      <tr style=\"justify-content: center; text-align: center;\"> \r\n        <th>#Orden</th>\r\n        <th>Usuario</th>\r\n        <th>Monto</th>\r\n        <th>Fecha</th>\r\n\r\n      </tr>\r\n    </thead>\r\n    <tbody style=\"justify-content: center; text-align: center;\">\r\n      <tr *ngFor=\"let item of referredCommissions\" style=\"justify-content: center; text-align: center;\">\r\n        <td> {{(item.order_id!=0)?item.order_id:'N/A'}} </td>\r\n        <th> {{(item.referenciado_id!=0)?item.name:'N/A'}} </th>\r\n        <th> ${{item.commission}} MXN</th>\r\n        <th> {{(item.validity_at)?item.validity_at:'No Expira'}} </th>\r\n      </tr>\r\n    </tbody>\r\n  </table>\r\n\r\n\r\n\r\n  <!-- <div style=\"text-align:center\">\r\n    <h3>Vigencia</h3>\r\n    <p style=\"color:#00b050;\r\n\r\n    font-size: 1.5em;\">12/02/23</p>\r\n  </div> -->\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n</ion-footer>");

/***/ }),

/***/ "./src/app/referred/referred-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/referred/referred-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: ReferredPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReferredPageRoutingModule", function() { return ReferredPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _referred_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./referred.page */ "./src/app/referred/referred.page.ts");




const routes = [
    {
        path: '',
        component: _referred_page__WEBPACK_IMPORTED_MODULE_3__["ReferredPage"]
    }
];
let ReferredPageRoutingModule = class ReferredPageRoutingModule {
};
ReferredPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ReferredPageRoutingModule);



/***/ }),

/***/ "./src/app/referred/referred.module.ts":
/*!*********************************************!*\
  !*** ./src/app/referred/referred.module.ts ***!
  \*********************************************/
/*! exports provided: ReferredPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReferredPageModule", function() { return ReferredPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _referred_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./referred-routing.module */ "./src/app/referred/referred-routing.module.ts");
/* harmony import */ var _referred_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./referred.page */ "./src/app/referred/referred.page.ts");







let ReferredPageModule = class ReferredPageModule {
};
ReferredPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _referred_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReferredPageRoutingModule"]
        ],
        declarations: [_referred_page__WEBPACK_IMPORTED_MODULE_6__["ReferredPage"]]
    })
], ReferredPageModule);



/***/ }),

/***/ "./src/app/referred/referred.page.scss":
/*!*********************************************!*\
  !*** ./src/app/referred/referred.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  /*   --background: url(\"../../assets/background_login.jpeg\");\n    background-repeat: no-repeat;\n    background-size: cover; */\n  --background: white;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n\n.header {\n  --background: white;\n  color: #FFF;\n  text-align: center;\n  width: 100%;\n  padding: 0px;\n}\n\n.header ion-text {\n  margin: auto;\n  display: block;\n  font-size: 1rem;\n}\n\n.green {\n  background: #00b050;\n}\n\nion-row {\n  padding-left: 5px;\n  padding-right: 5px;\n}\n\nion-tab-bar, ion-tab-button {\n  background-color: #ec760a;\n}\n\nion-icon {\n  color: #d7d8da;\n}\n\nion-footer {\n  display: block;\n  position: initial !important;\n  order: 1;\n  order: 1;\n  width: 100%;\n  z-index: 10;\n}\n\nion-item {\n  --border-color: white !important;\n}\n\n#commissions {\n  font-family: Arial, Helvetica, sans-serif;\n  border-collapse: collapse;\n  width: 100%;\n  margin-top: 2em;\n}\n\n#commissions td, #commissions th {\n  border: 1px solid #ddd;\n  padding: 4px;\n}\n\n#commissions tr:nth-child(even) {\n  background-color: #f2f2f2;\n}\n\n#commissions th {\n  padding-top: 2px;\n  padding-bottom: 2px;\n  text-align: left;\n  color: black;\n  color: black;\n  font-size: 0.8em;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2FsZnJlZG8vQWxmcmVkby9QZXJzb25hbC9Qcm95ZWN0b3MvRnJlc2tvL2ZyZXNrby1hcHAvc3JjL2FwcC9yZWZlcnJlZC9yZWZlcnJlZC5wYWdlLnNjc3MiLCJzcmMvYXBwL3JlZmVycmVkL3JlZmVycmVkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFOzs2QkFBQTtFQUdFLG1CQUFBO0VBQ0UsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FDQ047O0FERUE7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUNFRjs7QURDQTtFQUNFLG1CQUFBO0FDRUY7O0FEQ0E7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0FDRUY7O0FEQ0E7RUFDRSx5QkFBQTtBQ0VGOztBRENDO0VBQ0UsY0FBQTtBQ0VIOztBRENDO0VBQ0MsY0FBQTtFQUNBLDRCQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQ0VGOztBRENBO0VBQ0UsZ0NBQUE7QUNFRjs7QURDQTtFQUNFLHlDQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ0VGOztBRENBO0VBQ0Usc0JBQUE7RUFDQSxZQUFBO0FDRUY7O0FEQ0E7RUFBZ0MseUJBQUE7QUNHaEM7O0FEQUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QUNHSiIsImZpbGUiOiJzcmMvYXBwL3JlZmVycmVkL3JlZmVycmVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAvKiAgIC0tYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL2JhY2tncm91bmRfbG9naW4uanBlZ1wiKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyAqL1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gIH1cclxuXHJcbi5oZWFkZXJ7XHJcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICBjb2xvcjogI0ZGRjtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMHB4O1xyXG59XHJcbi5oZWFkZXIgaW9uLXRleHR7XHJcbiAgbWFyZ2luOiBhdXRvO1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGZvbnQtc2l6ZTogMS4wcmVtO1xyXG59XHJcblxyXG4uZ3JlZW4ge1xyXG4gIGJhY2tncm91bmQ6ICMwMGIwNTA7XHJcbn1cclxuXHJcbmlvbi1yb3cge1xyXG4gIHBhZGRpbmctbGVmdDogNXB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6NXB4O1xyXG59XHJcblxyXG5pb24tdGFiLWJhciwgaW9uLXRhYi1idXR0b257XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VjNzYwYTtcclxuIH1cclxuIFxyXG4gaW9uLWljb257XHJcbiAgIGNvbG9yOiAjZDdkOGRhO1xyXG4gfVxyXG5cclxuIGlvbi1mb290ZXIge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHBvc2l0aW9uOiBpbml0aWFsICFpbXBvcnRhbnQ7XHJcbiAgb3JkZXI6IDE7XHJcbiAgb3JkZXI6IDE7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgei1pbmRleDogMTA7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICAtLWJvcmRlci1jb2xvcjogd2hpdGUgIWltcG9ydGFudDtcclxufVxyXG5cclxuI2NvbW1pc3Npb25zIHtcclxuICBmb250LWZhbWlseTogQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZjtcclxuICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1hcmdpbi10b3A6IDJlbTtcclxufVxyXG5cclxuI2NvbW1pc3Npb25zIHRkLCAjY29tbWlzc2lvbnMgdGgge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcbiAgcGFkZGluZzogNHB4O1xyXG59XHJcblxyXG4jY29tbWlzc2lvbnMgdHI6bnRoLWNoaWxkKGV2ZW4pe2JhY2tncm91bmQtY29sb3I6ICNmMmYyZjI7fVxyXG5cclxuXHJcbiNjb21taXNzaW9ucyB0aCB7XHJcbiAgcGFkZGluZy10b3A6IDJweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMnB4O1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG4gIGNvbG9yOiBibGFjaztcclxuICAgIGZvbnQtc2l6ZTogMC44ZW07XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn0iLCJpb24tY29udGVudCB7XG4gIC8qICAgLS1iYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvYmFja2dyb3VuZF9sb2dpbi5qcGVnXCIpO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgKi9cbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4uaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgY29sb3I6ICNGRkY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDBweDtcbn1cblxuLmhlYWRlciBpb24tdGV4dCB7XG4gIG1hcmdpbjogYXV0bztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbn1cblxuLmdyZWVuIHtcbiAgYmFja2dyb3VuZDogIzAwYjA1MDtcbn1cblxuaW9uLXJvdyB7XG4gIHBhZGRpbmctbGVmdDogNXB4O1xuICBwYWRkaW5nLXJpZ2h0OiA1cHg7XG59XG5cbmlvbi10YWItYmFyLCBpb24tdGFiLWJ1dHRvbiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlYzc2MGE7XG59XG5cbmlvbi1pY29uIHtcbiAgY29sb3I6ICNkN2Q4ZGE7XG59XG5cbmlvbi1mb290ZXIge1xuICBkaXNwbGF5OiBibG9jaztcbiAgcG9zaXRpb246IGluaXRpYWwgIWltcG9ydGFudDtcbiAgb3JkZXI6IDE7XG4gIG9yZGVyOiAxO1xuICB3aWR0aDogMTAwJTtcbiAgei1pbmRleDogMTA7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1ib3JkZXItY29sb3I6IHdoaXRlICFpbXBvcnRhbnQ7XG59XG5cbiNjb21taXNzaW9ucyB7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xuICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luLXRvcDogMmVtO1xufVxuXG4jY29tbWlzc2lvbnMgdGQsICNjb21taXNzaW9ucyB0aCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XG4gIHBhZGRpbmc6IDRweDtcbn1cblxuI2NvbW1pc3Npb25zIHRyOm50aC1jaGlsZChldmVuKSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmMmYyZjI7XG59XG5cbiNjb21taXNzaW9ucyB0aCB7XG4gIHBhZGRpbmctdG9wOiAycHg7XG4gIHBhZGRpbmctYm90dG9tOiAycHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGNvbG9yOiBibGFjaztcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDAuOGVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */");

/***/ }),

/***/ "./src/app/referred/referred.page.ts":
/*!*******************************************!*\
  !*** ./src/app/referred/referred.page.ts ***!
  \*******************************************/
/*! exports provided: ReferredPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReferredPage", function() { return ReferredPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_global_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/global.service */ "./src/app/services/global.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../globals */ "./src/app/globals.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/__ivy_ngcc__/ngx/index.js");








let ReferredPage = class ReferredPage {
    constructor(apiService, router, platform, g, toastController, global, iab) {
        this.platform = platform;
        this.g = g;
        this.toastController = toastController;
        this.global = global;
        this.iab = iab;
        this.isLoading = false;
        this.referredCommissions = 0;
        this.referreds = 0;
        this.balance = 0;
        this.sliderOptions = {
            zoom: false,
            slidesPerView: 1,
            spaceBetween: 20,
            pager: true,
            autoHeight: true,
        };
        console.log('User', this.global.user_info);
        this.apiService = apiService;
        this.router = router;
    }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.global.logout();
        });
    }
    ionViewWillEnter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("User", this.global.user_info);
            if (this.global.user_info != null) {
                if (this.global.user_info.iduser) {
                    yield this.global.showLoading("Cargando referidos..");
                    yield this.apiService.updateDevice(this.global.user_info.iduser, this.global.device_id).toPromise().then((resp) => {
                        console.log('Respuesta', resp);
                    });
                    yield this.obtenerInformacionUser();
                    yield this.getReferredCommissions();
                    this.global.dismissLoading();
                }
                else {
                    this.router.navigate(['home']);
                }
            }
            // this.backButtonSubscription = this.platform.backButton.subscribe(async () => {
            //   navigator['app'].exitApp();
            // });
            //this.verProductos(0);
        });
    }
    ionViewDidLeave() {
        // this.backButtonSubscription.unsubscribe();
    }
    obtenerInformacionUser() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.apiService.getUser(this.global.user_info.iduser).toPromise().then((response) => {
                if (response.success) {
                    this.global.user_info = response.data;
                    this.global.user_info.promotions_discount = response.promotions_discount;
                    this.global.user_info.promotions_freedelivery = response.promotions_freedelivery;
                    this.global.user_info.promotions_freeproduct = response.promotions_freeproduct;
                    this.global.user_info.anuncios = response.anuncios;
                    this.global.user_info.paquetes = response.paquetes;
                    for (var i = 0; i < this.global.user_info.promotions_discount.length; i++) {
                        this.global.user_info.promotions_discount[i].url = "data:image/png;base64," + this.global.user_info.promotions_discount[i].url;
                        if (this.global.user_info.promotions_discount[i].promotions_carrousel == 1) {
                            this.global.promotions_carrousel.push(this.global.user_info.promotions_discount[i]);
                        }
                    }
                    for (var i = 0; i < this.global.user_info.promotions_freedelivery.length; i++) {
                        this.global.user_info.promotions_freedelivery[i].url = "data:image/png;base64," + this.global.user_info.promotions_freedelivery[i].url;
                        if (this.global.user_info.promotions_freedelivery[i].promotions_carrousel == 1) {
                            this.global.promotions_carrousel.push(this.global.user_info.promotions_freedelivery[i]);
                        }
                    }
                    for (var i = 0; i < this.global.user_info.promotions_freeproduct.length; i++) {
                        this.global.user_info.promotions_freeproduct[i].url = "data:image/png;base64," + this.global.user_info.promotions_freeproduct[i].url;
                        if (this.global.user_info.promotions_freeproduct[i].promotions_carrousel == 1) {
                            this.global.promotions_carrousel.push(this.global.user_info.promotions_freeproduct[i]);
                        }
                    }
                    for (var i = 0; i < this.global.user_info.anuncios.length; i++) {
                        this.global.user_info.anuncios[i].imagen = "data:image/png;base64," + this.global.user_info.anuncios[i].imagen;
                    }
                    for (var i = 0; i < this.global.user_info.paquetes.length; i++) {
                        this.global.user_info.paquetes[i].imagen = "data:image/png;base64," + this.global.user_info.paquetes[i].url;
                    }
                    this.global.setItemStorage('user_info', JSON.stringify(this.global.user_info));
                }
            }).catch(error => {
                console.error('Error', error);
            });
        });
    }
    verProductos(id) {
        this.router.navigate(['/tabs2/products', id]);
    }
    shoppingList() {
        this.router.navigate(['finish-order']);
    }
    verPromosDisponibles() {
        this.router.navigate(['promos-disponibles']);
    }
    verPaquetesDisponibles() {
        this.router.navigate(['paquetes-disponibles']);
    }
    viewOrders() {
        if (this.g.idUser === -46) {
            this.global.showToast("Para ver los pedidos debes iniciar sesion", "danger");
        }
        else {
            this.router.navigate(['orders']);
        }
    }
    openWhatsapp() {
        this.iab.create('http://api.whatsapp.com/send?phone=' + this.global.getAppConfigFlag("WHATSAPP"), "_system");
    }
    verPerfil() {
    }
    getReferredCommissions() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.apiService
                .getReferredCommissionsByUserId(this.global.user_info.iduser)
                .subscribe((response) => {
                let commissions = [];
                let total = 0;
                this.referreds = response.referreds.total;
                this.referredCommissions = 0;
                if (response.commissions.length >= 1) {
                    let commisionsResponse = response.commissions;
                    Object.entries(commisionsResponse).forEach(([key, value]) => {
                        commissions.push(value);
                        total = total + parseFloat(value.commission);
                    });
                    this.referredCommissions = commissions;
                }
                this.balance = total;
            });
        });
    }
};
ReferredPage.ctorParameters = () => [
    { type: _services_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"] },
    { type: _globals__WEBPACK_IMPORTED_MODULE_5__["Globals"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _services_global_service__WEBPACK_IMPORTED_MODULE_1__["GlobalService"] },
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_7__["InAppBrowser"] }
];
ReferredPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-referred',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./referred.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/referred/referred.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./referred.page.scss */ "./src/app/referred/referred.page.scss")).default]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_services_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"],
        _globals__WEBPACK_IMPORTED_MODULE_5__["Globals"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"],
        _services_global_service__WEBPACK_IMPORTED_MODULE_1__["GlobalService"],
        _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_7__["InAppBrowser"]])
], ReferredPage);



/***/ })

}]);
//# sourceMappingURL=referred-referred-module-es2015.js.map