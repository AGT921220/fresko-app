import { Injectable } from '@angular/core';

@Injectable()
export class Globals {

  idUser = -1;
  pickUpNotes = '';
  fruits = [];
  vegetables = [];
  spices = [];
  carnes = [];
  cremeria = [];
  otros = [];
  horario = "";
  promo_seleccionada = null;
  metodo_pago = "";
  shoppingList = [];
  total_orden = 0;
  notes = '';

}
