export interface Card {
    cardNumber:any;
    cardNumberHidden:any;
    cardMonth:any;
    cardYear:any;
    cardCVV:any;
    cardName:any;
    token:any;
    bank:any;
    country:any;
    lastFourDigits:any;
    type:any;
}
