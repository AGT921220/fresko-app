export const CustomIcons = {
    cart: "../assets/cart.svg",
    visa: "../assets/tarjeta-visa.svg",
    mastercard: "../assets/tarjeta-mastercard.svg",
    american_express: "../assets/tarjeta-american-express.svg",
    cvv: "../assets/cvv.svg"
}
